package com.fatec.sigvsmsuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SigvsmsuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
