package com.fatec.sigvsmsuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SigvsmsuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SigvsmsuserApplication.class, args);
	}

}
